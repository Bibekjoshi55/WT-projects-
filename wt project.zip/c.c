// #include<stdio.h>
// int main(){
//     int n,arm=0,r,c;

//     printf("Enter any number");
//     scanf("%d",&n);

//     c=n;
//     while(n>0){
//         r = n % 10;
//         arm = (r*r*r)+arm;
//         n=n/10;
//     }
//     if(c==arm){
//         printf("Armstrong number");
//     } else{
//         printf("Not Armstrong number");
//     }
//     return 0;
// }

#include <stdio.h>
int fact(int);
int main()
{
int a, f;
printf("Enter the number :\n");
scanf("%d", &a);
f = fact(a);
printf("factorial = %d", f);
}
int fact(int n)
{
int i, fact = 1;
for (i = 1; i <= n; i++)
	fact = fact * i;
return fact;
}
